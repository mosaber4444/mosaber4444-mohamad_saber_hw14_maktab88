const express = require('express');
const app = express();
const productRouter = require('./assets/js/product');


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use('/product', productRouter);


app.get('/product', (req, res) => {
	res.send('home');
});

app.listen(1111);
