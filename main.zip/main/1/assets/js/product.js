const express = require('express');
const router = express.Router();
const fs = require('fs');
const db = require('../db/products-data.json');

const path = require('path');


//render
router.get('/get-all-products',(req , res )=>{
    res.json(db);
})

//res product with id 
router.get('/get-product/:id',(req , res )=>{
    const a = db.find(el => el.id == req.params.id)
    console.log(req.params.id);
    res.json(a);
})

//create 
router.post('/create-product',(req , res )=>{
    const object = {
        id: req.body.id ,
        title: req.body.title,
        price: req.body.price,
        rating: req.body.rating,
        stock: req.body.stock,
        brand: req.body.brand,
        category: req.body.category
    }
    db.push(object);

    try {
        fs.writeFileSync(path.join(__dirname, '../db/products-data.json'),JSON.stringify(db));

    } catch (error) {
        console.log(error);
    }
    res.json(db);
})

//updat 
router.put('/update/:id' , (req , res ) => {
    const s = db.find(el => el.id == req.params.id )
    if (req.body.id) s.id = req.body.id ;
    if (req.body.title) s.title = req.body.title ;
    if (req.body.price) s.price = req.body.price ;
    if (req.body.rating) s.rating = req.body.rating ;
    if (req.body.stock) s.stock = req.body.stock ;
    if (req.body.brand) s.brand = req.body.brand ;
    if (req.body.category) s.category = req.body.category ;
    try {
        fs.writeFileSync(path.join(__dirname, '../db/products-data.json'),JSON.stringify(db));

    } catch (error) {
        console.log(error);
    }
    res.json(s)
})

// remove product
router.delete('/removeProduct/:productId', (req, res) => {
	const productsTemp = db.filter(x => x.id != req.params.productId);

	try {
        fs.writeFileSync(path.join(__dirname, '../db/products-data.json'),JSON.stringify(productsTemp));
	} catch (err) {
		console.log(err);
		return res.status(400).send('Try again later!');
	}

	res.status(204).send('remove product');
});

module.exports = router;