const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const products = require('../db/product.json');

// create new product
router.post('/newProduct', (req, res) => {
	const newProduct = {
		name: req.body.name,
		date: req.body.date,
		id: req.body.id
	};

	products.push(newProduct);

	try {
		fs.writeFileSync(
			path.join(__dirname, '../db/product.json'),
			JSON.stringify(products)
		);
	} catch (err) {
		console.log(err);
		return res.status(400).send('Try again later!');
	}

	res.status(201).json(newProduct);
});

// read products
router.get('/getProducts', (req, res) => {
	console.log(products);

	return res.json(products);
});

// read single product
router.get('/getProduct/:productId', (req, res) => {
	console.log(req.params.productId);

	const product = products.find(x => x.id == req.params.productId);

	if (!product) {
		return res.status(404).send('Not Found!');
	}

	console.log(product);

	return res.json(product);
});

// update product
router.put('/editProduct/:productId', (req, res) => {
	const product = products.find(x => x.id == req.params.productId);

	if (req.body.date) product.date = req.body.date;
	if (req.body.name) product.name = req.body.name;

	try {
		fs.writeFileSync(
			path.join(__dirname, '../db/product.json'),
			JSON.stringify(products)
		);
	} catch (err) {
		console.log(err);
		return res.status(400).send('Try again later!');
	}

	res.json(product);
});

// remove product
router.delete('/removeProduct/:productId', (req, res) => {
	const productsTemp = products.filter(x => x.id != req.params.productId);

	try {
		fs.writeFileSync(
			path.join(__dirname, '../db/product.json'),
			JSON.stringify(productsTemp)
		);
	} catch (err) {
		console.log(err);
		return res.status(400).send('Try again later!');
	}

	return res.json(product);
});

module.exports = router;
