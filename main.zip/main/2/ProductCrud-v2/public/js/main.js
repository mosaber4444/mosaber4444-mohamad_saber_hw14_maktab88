// * GET
const table = $('#table')

 async function render() {
	table.empty();
	try {
		const responseObject = await fetch(
			'http://localhost:8000/product/getProducts'
		);
		// data parse
		const userData = await responseObject.json();
		let arrK = Object.keys(userData[0])
		table.append('<tr>')
		for (let i = 0 ; i < arrK.length ; i++){
			table.append(`<th>${arrK[i]}</th>`)
		}
		table.append(`<th>edit</th>`)
		table.append('</tr>')
		let arrV ;
		for(let i = 0 ; i < userData.length ; i++){
			arrV = Object.values(userData[i])
			table.append('<tr>')
			for (let index = 0; index < arrV.length; index++) {
				table.append(`<td>${arrV[index]}</td>`)
			}
			table.append(`<td><button type="button">edit</button>  <button type="button" onclick="del(${userData[i]['id']})" >delete</button></td>`)
			table.append('</tr>')
		}

		return userData ;
	} catch (error) {
		console.log(error?.message);
	}
};

render();

function del (index){
	fetch('http://localhost:8000/product/removeProduct/'+ index, {
		method: 'DELETE',
	  })
	  .then(res => res.text()) // or res.json()
	  .then(res => render())
}